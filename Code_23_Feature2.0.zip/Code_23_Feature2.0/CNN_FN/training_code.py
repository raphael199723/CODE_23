import pandas as pd
import sys

import numpy as np
from tensorflow import keras
from tensorflow.keras import layers
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout,BatchNormalization,Conv1D
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import RMSprop,Adam
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler ,MinMaxScaler
import os
import matplotlib.pyplot as plt
path='format_combine/train/'
feature_num = 23
slot_num = 10 
RP_num = 6

def preprocessing(path=str, feature_num=int):
	csv_name_list=[x for x in os.listdir(path)]
	x_train=[]
	y_label=[]
	reg=[]
	reg1=[]
	for i in sorted(csv_name_list):
		print(i)
		x_train.append(np.array(pd.read_csv(path+i, na_filter = False, header = None))) # read_csv : read csv file; na_filter : whether detect missing value markers or not
		y_label.append(''.join([k for k in i if k.isdigit()]))
		#print(x_train)
	#print(y_label)
	for i in range(len(x_train)):
		print(len(x_train[i]))
		for j in range(len(x_train[i])):
			#print(x_train[i][j])
			tmp = str(x_train[i][j])
			#print(tmp)
			#feature_num = len(tmp)
			reg.append(tmp.replace("['","").replace("']","").replace("\\t",",").split(','))
			if j%6==0:
				reg1.append(y_label[i])
				print("j: ",j)

	N = len(reg)
	print('reg: ',len(reg))
	print('reg1: ',len(reg1))
	x_n_train = np.array(reg)#.reshape(N,feature_num)
	y_n_label = np.array(reg1).reshape(int(N/6),1) # N,1
	# print((x_n_train.dtype))
	# print((y_n_label.dtype))
	x_n_train = x_n_train.astype('float64') 
	y_n_label_not_one_hot = y_n_label.astype('float64')
	print("x_n_train: ",x_n_train)
	onehotencoder = OneHotEncoder()
	y_n_label=onehotencoder.fit_transform(y_n_label_not_one_hot).toarray()


	# Standardization
	save_std_mean_value = np.zeros([2,feature_num])
	tmp = np.zeros([N, feature_num])

	std_x = np.std(x_n_train, axis = 0) # axis=0，計算每一column的標準差
	mean_x = np.mean(x_n_train, axis = 0) # axis=0，計算每一column的平均值

	for j in range(feature_num):
		save_std_mean_value[0,j] = std_x[j]
		save_std_mean_value[1,j] = mean_x[j]
		for i in range(N): 
#			if std_x[j] != 0:
			tmp[i][j] = (x_n_train[i][j] - mean_x[j]) / std_x[j]

	if not os.path.exists("format_combine"):
		os.mkdir("format_combine")
	if not os.path.exists("format_combine/std_mean"):
		os.mkdir("format_combine/std_mean")
	save_std_mean_value = pd.DataFrame(save_std_mean_value)
	save_std_mean_value.to_csv("format_combine/std_mean/std_mean_value.csv",index = False,header = False)
	x_n_train = tmp
#	print("x_n_train: ",x_n_train)
#	print(y_n_label)

	x_n_train = x_n_train.reshape(int(len(x_n_train)/6),6,23,1) #B,W,H,Channel ; B*W=total num
	return x_n_train, y_n_label, y_n_label_not_one_hot


def create_CNN2D_2l():
    model = keras.models.Sequential([
            tf.keras.layers.Conv2D(64, 3, activation='relu',input_shape=(6,23,1)),
            tf.keras.layers.MaxPool2D(pool_size=3, strides=1, padding='valid'),
            tf.keras.layers.Flatten(),
            tf.keras.layers.Dense(512, activation='relu'),
            tf.keras.layers.Dropout(0.1),
            tf.keras.layers.Dense(512, activation='relu'),
            tf.keras.layers.Dropout(0.1),
            tf.keras.layers.Dense(512, activation='relu'),
            tf.keras.layers.Dropout(0.1),
            tf.keras.layers.Dense(512, activation='relu'),
            tf.keras.layers.Dropout(0.1),    
            tf.keras.layers.Dense(6, activation='softmax')
            ],name='1Layers 2D CNN')
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    return model

def create_FN(feature_num=int,neu1=int,neu2=int,neu3=int,neu4=int,acti1=str,acti2=str,acti3=str,acti4=str,acti5=str):
	model = Sequential()
	model.add(Dense(neu1, activation=acti1, input_shape=(feature_num,)))
	model.add(Dense(neu2, activation=acti2))
	model.add(Dense(neu3, activation=acti3))
	model.add(Dense(neu4, activation=acti4))
	model.add(Dense(2, activation=acti5))
	model.summary()
	# Choose loss function and optimizing method
	keras.optimizers.Adam(lr=1e-3 , beta_1=0.9, beta_2=0.99, epsilon=1e-8, decay=0.0)
	model.compile(loss='mse',optimizer='Adam',metrics=['mean_absolute_error'])
	return model


def save_model_plt(model=keras.models,history=keras.models,model_name=str,loss_plt_name=str,acc_plt_name=str):
	model.save(model_name)
	plt.plot(history.history['loss'])
	plt.plot(history.history['val_loss'])
	plt.title('model loss')
	plt.ylabel('loss')
	plt.xlabel('epoch')
	plt.legend(['train', 'validation'], loc='upper right')
	plt.savefig(loss_plt_name)
	plt.clf()

	plt.plot(history.history['acc'])
	plt.plot(history.history['val_acc'])
	plt.title('model accuracy')
	plt.ylabel('accuracy')
	plt.xlabel('epoch')
	plt.legend(['train', 'validation'], loc='upper right')
	plt.savefig(acc_plt_name)
	plt.clf()

def save_FN_plt(model=keras.models,history=keras.models,model_name=str,loss_plt_name=str,mae_plt_name=str):
	model.save(model_name)
	plt.plot(history.history['loss'])
	plt.plot(history.history['val_loss'])
	plt.title('FN loss')
	plt.ylabel('loss')
	plt.xlabel('epoch')
	plt.legend(['train', 'validation'], loc='upper right')
	plt.savefig(loss_plt_name)
	plt.clf()

	plt.plot(history.history['mean_absolute_error'])
	plt.plot(history.history['val_mean_absolute_error'])
	plt.title('FN mae')
	plt.ylabel('mae')
	plt.xlabel('epoch')
	plt.legend(['train', 'validation'], loc='upper right')
	plt.savefig(mae_plt_name)
	plt.clf()

def main():
	model = create_CNN2D_2l()
	model.summary()
	early_stopping = EarlyStopping(monitor = 'val_loss', patience = 15, verbose = 1,mode = 'min')
	x_n_train, y_n_label, y_n_label_not_one_hot = preprocessing(path, feature_num)
	print("xtrain: ",len(x_n_train))
	print("ylabel: ",len(y_n_label))
	history = model.fit(x_n_train, y_n_label, epochs=1500,batch_size=128, validation_split=0.01, shuffle=True, callbacks=[early_stopping])
	save_model_plt(model=model,history=history,model_name='CNN.h3',loss_plt_name='model_loss.pdf',acc_plt_name='model_acc.pdf')  
	predict_value = model.predict(x_n_train)
	x_n_train_1 = np.array([])
	y_n_label_1 = np.array([])
	RP1 = np.array([-274,280])
	RP2 = np.array([0,280])
	RP3 = np.array([263.5,280])
	RP4 = np.array([-274,0])
	RP5 = np.array([263.5,0])
	RP6 = np.array([-274,-317])
	RP7 = np.array([0,-317])
	RP8 = np.array([263.5,-317])
	for i in range(predict_value.shape[0]):
		tmp=RP1*predict_value[i][0]+RP3*predict_value[i][1]+RP4*predict_value[i][2]+RP5*predict_value[i][3]+RP6*predict_value[i][4]+RP8*predict_value[i][5]

		if predict_value.shape[0] == 0:
			x_n_train_1 = np.array([tmp])
		else:
			x_n_train_1 = np.append(x_n_train_1, tmp)
		#print(y_n_label_not_one_hot)
		tmp1 = y_n_label_not_one_hot[i][0]
		if tmp1 == 1:
			if predict_value.shape[0] == 0:
				y_n_label_1 = np.array([-274,280])
			else:
				y_n_label_1 = np.append(y_n_label_1, [-274,280])
			print("1")
		elif tmp1 == 2:
			if predict_value.shape[0] == 0:
				y_n_label_1 = np.array([263.5,280])
			else:
				y_n_label_1 = np.append(y_n_label_1, [263.5,280])
			print("2")
		elif tmp1 == 3:
			if predict_value.shape[0] == 0:
				y_n_label_1 = np.array([-274,0])
			else:
				y_n_label_1 = np.append(y_n_label_1, [-274,0])
			print("3")
		elif tmp1 == 4:
			if predict_value.shape[0] == 0:
				y_n_label_1 = np.array([263.5,0])
			else:
				y_n_label_1 = np.append(y_n_label_1, [263.5,0])
			print("4")
		elif tmp1 == 5:
			if predict_value.shape[0] == 0:
				y_n_label_1 = np.array([-274,-317])
			else:
				y_n_label_1 = np.append(y_n_label_1, [-274,-317])
			print("5")
		else:
			if predict_value.shape[0] == 0:
				y_n_label_1 = np.array([263.5,-317])
			else:
				y_n_label_1 = np.append(y_n_label_1, [263.5,-317])
			print("6")
		#print("len_<of_ylabel_1: ",(y_n_label_1))

	print(len(x_n_train_1.reshape(-1,slot_num*2)),len(y_n_label_1.reshape(-1,slot_num*2)[:,:2]))

	model1 = create_FN(feature_num=slot_num*2,neu1=100,neu2=64,neu3=48,neu4=12,acti1='relu',acti2='relu',acti3='relu',acti4='relu',acti5='linear')
	print(len(x_n_train_1.reshape(-1,slot_num*2)),len( y_n_label_1.reshape(-1,slot_num*2)[:,:2]))
	history1 = model1.fit(x_n_train_1.reshape(-1,slot_num*2), y_n_label_1.reshape(-1,slot_num*2)[:,:2], epochs=1500, batch_size=128, validation_split=0.01, shuffle=True, callbacks=[early_stopping])
	save_FN_plt(model=model1,history=history1,model_name='FN.h5',loss_plt_name='FN_loss.pdf',mae_plt_name='FN_mae.pdf')

if __name__ == "__main__":
	main()

