import numpy as np
import pandas as pd
import keras
import sys
from keras.models import Sequential
from keras.layers import Dense
import os
path='format_combine/test/'
std_mean_value = np.array(pd.read_csv('format_combine/std_mean/std_mean_value.csv', na_filter = False, header = None))
feature_num = 23
slot_num = 10
RP_num = [0,102,111,129,179,170,151]
def preprocessing(path=str, feature_num=int):
	csv_name_list=[x for x in os.listdir(path)]
	x_test = []
	y_label = []
	reg = []
	reg1 = []
	for i in sorted(csv_name_list):
		x_test.append(np.array(pd.read_csv(path+i, na_filter = False, header = None))) # read_csv : 讀取檔案 ; na_filter : 是否檢查丟失值
		y_label.append(''.join([k for k in i if k.isdigit()]))
	for i in range(len(x_test)):
		#print(len(x_test[i]))
		for j in range(len(x_test[i])):
			tmp = str(x_test[i][j])
			#feature_num = len(tmp)
			reg.append(tmp.replace("['","").replace("']","").replace("\\t",",").split(','))
			if y_label[i] == '1':
				reg1.append('-274,280'.split(','))
			elif y_label[i] == '2':
				reg1.append('263.5,280'.split(','))
			elif y_label[i] == '3':
				reg1.append('-274,0'.split(','))
			elif y_label[i] == '4':
				reg1.append('263.5,0'.split(','))
			elif y_label[i] == '5':
				reg1.append('-274,-317'.split(','))
			else:
				reg1.append('263.5,-317'.split(','))
	N = len(reg)
	#print('N: ',N)
	x_n_test = np.array(reg).reshape(N,feature_num) # N,23
	y_n_label = np.array(reg1).reshape(N,2) # N,2
	# print((x_n_test.dtype))
	# print((y_n_label.dtype))
	x_n_test = x_n_test.astype('float64') 
	y_n_label = y_n_label.astype('float64')

	# Standardization
	tmp = np.zeros([N, feature_num])

	for j in range(feature_num):
		print("std_check: ",std_mean_value[0,j])
		print("mean_check: ",std_mean_value[1,j])
		std_t = std_mean_value[0,j]
		mean_t = std_mean_value[1,j]
		for i in range(N): 
			tmp[i][j] = (x_n_test[i][j] - mean_t) / std_t

	x_n_test = tmp
	print('x_n_test[0]',x_n_test[0],';size:',len(x_n_test[0]))

	return x_n_test, y_n_label

def main():
	x_n_test, y_n_label = preprocessing(path, feature_num)

	model = keras.models.load_model('SLN.h5')
	predict_value = model.predict(x_n_test)

	SLN_output = np.array([])
	RP1 = np.array([-274,280])
	RP2 = np.array([0,280])
	RP3 = np.array([263.5,280])
	RP4 = np.array([-274,0])
	RP5 = np.array([263.5,0])
	RP6 = np.array([-274,-317])
	RP7 = np.array([0,-317])
	RP8 = np.array([263.5,-317])
	print('len:',predict_value.shape[0])
	for i in range(predict_value.shape[0]):
		tmp=RP1*predict_value[i][0]+RP3*predict_value[i][1]+RP4*predict_value[i][2]+RP5*predict_value[i][3]+RP6*predict_value[i][4]+RP8*predict_value[i][5]
		print(tmp)
		if SLN_output.shape[0] == 0:
			SLN_output = np.array([tmp])
		else:
			SLN_output = np.append(SLN_output, tmp)

	out_pred_format = []
	out_label_format = []
	str1 = ','
	for i in range((SLN_output).reshape(-1,2).shape[0]):
		out_pred_format.append(str1.join( (SLN_output.reshape(-1,2)[i]).astype('str') ))
		out_label_format.append(str1.join( (y_n_label.reshape(-1,2)[i]).astype('str') ))
	out = pd.DataFrame([out_pred_format,out_label_format]).T
	out.columns = ["ans","label"]
	out.to_csv('SLN_output_predict.csv',index = False) 

	model1 = keras.models.load_model('FN.h5')
	index = 0
	ans = np.array([])
	label = np.array([])
	for i in range(1,7):
		index = index + RP_num[i]
		remove_num = RP_num[i] % slot_num
		print(index-RP_num[i],index-remove_num)
		tmp1 = np.array([out_pred_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)
		#print(tmp1)
		SLN_output_by_slot = np.array([])
		for j in range(tmp1.shape[0]):
			for k in range(10):
				print(tmp1[j][k])
				if SLN_output_by_slot.shape[0] == 0:
					SLN_output_by_slot = np.array([str(tmp1[j][k]).split(',')])
				else:
					SLN_output_by_slot = np.append(SLN_output_by_slot, [str(tmp1[j][k]).split(',')])
		SLN_output_by_slot = SLN_output_by_slot.astype('float64')
		print(len(SLN_output_by_slot.reshape(-1,slot_num*2)))
		predict_value1 = model1.predict(SLN_output_by_slot.reshape(-1,slot_num*2))
		if ans.shape[0] == 0:
			ans = np.array([predict_value1])
		else:
			ans = np.append(ans, predict_value1)

		label_tmp = np.array([out_label_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)[:,0]
		if label.shape[0] == 0:
			label = np.array([label_tmp])
		else:
			label = np.append(label, label_tmp)
	out_pred_format = []
	str1 = ','
	for i in range((ans).reshape(-1,2).shape[0]):
		out_pred_format.append(str1.join( (ans.reshape(-1,2)[i]).astype('str') ))
	out = pd.DataFrame([out_pred_format,label]).T
	out.columns = ["ans","label"]
	out.to_csv('SLN_and_FN_output_predict.csv',index = False) 

if __name__ == "__main__":
	main()
