import numpy as np
import pandas as pd
import sys
import os

file_name ='CNN_output_predict.csv'
file_name1='CNN_output_predict1.csv'
file_name2='CNN_output_predict2.csv'
file_name3='CNN_output_predict3.csv'
file_name4='CNN_output_predict4.csv'
file_name5='CNN_output_predict5.csv'
file_name6='CNN_output_predict6.csv'
file_name7='CNN_output_predict7.csv'
file_name8='CNN_output_predict8.csv'
file_name9='CNN_output_predict9.csv'

def load_data(path=str):
        csv = pd.read_csv(path)
        #csv = pd.DataFrame((csv['ans'].split(","))).to_numpy()
        #csv = str(csv)#pd.core.frame.DataFrame
        predict_value = []
        ground_truth = []
        for i in range(len(csv)):
                predict_value.append(csv['ans'][i].split(","))
                ground_truth.append(csv['label'][i].split(","))
        return predict_value,ground_truth


#label = pd.read_csv(file_name)
csv , ground_truth = load_data(file_name)
csv1 , ground_truth  = load_data(file_name1)
csv2 , ground_truth  = load_data(file_name2)
csv3 , ground_truth  = load_data(file_name3)
csv4 , ground_truth  = load_data(file_name4)
csv5 , ground_truth  = load_data(file_name5)
csv6 , ground_truth  = load_data(file_name6)
csv7 , ground_truth  = load_data(file_name7)
csv8 , ground_truth  = load_data(file_name8)
csv9 , ground_truth  = load_data(file_name9)

row, column = np.array(csv).shape
print("csv shape: ",row)
#rint("csv:",csv[0][0])
#rint("csv1:",csv1[0][0])
#rint("csv_csv1:",float(csv[0][0])+float(csv1[0][0]))# + csv1[0])
#total = np.array(csv)
#label = np.array(csv1) 

#total = np.zeros((row, column-1))
#label =  np.zeros((row, column-1))
#total = csv
#label = csv1
total = []
label = []
for i in range(row):
       total.append([int(x) for x in range(row)])
       label.append([int(x) for x in range(row)])
total_two_in_one = np.array([])
label_two_in_one = np.array([])
for j in range(len(csv)):
    for i in range(column):
#        total[j][i] = (float(csv[j][i]) + float(csv1[j][i]) + float(csv2[j][i]) + float(csv3[j][i]) + float(csv4[j][i]) + float(csv5[j][i]) + float(csv6[j][i]) + float(csv7[j][i]) + float(csv8[j][i]) + float(csv9[j][i])) / 10
#        label[j][i] =  float(ground_truth[j][i])

         if i == 0:
             total_two_in_one =  str((float(csv[j][i]) + float(csv1[j][i]) + float(csv2[j][i]) + float(csv3[j][i]) + float(csv4[j][i]) + float(csv5[j][i]) + float(csv6[j][i]) + float(csv7[j][i]) + float(csv8[j][i]) + float(csv9[j][i])) / 10)

             label_two_in_one = str(float(ground_truth[j][i]))
         else:
             total_two_in_one = total_two_in_one + ',' + str((float(csv[j][i]) + float(csv1[j][i]) + float(csv2[j][i]) + float(csv3[j][i]) + float(csv4[j][i]) + float(csv5[j][i]) + float(csv6[j][i]) + float(csv7[j][i]) + float(csv8[j][i]) + float(csv9[j][i])) / 10)
             label_two_in_one = label_two_in_one + ','+ str(float(ground_truth[j][i]))
#             total_two_in_one.append(','.join(str((float(csv[j][i]) + float(csv1[j][i]) + float(csv2[j][i]) + float(csv3[j][i]) + float(csv4[j][i]) + float(csv5[j][i]) + float(csv6[j][i]) + float(csv7[j][i]) + float(csv8[j][i]) + float(csv9[j][i])) / 10))) 
    print(total_two_in_one)#, total_two_in_one.shape)
    total[j] = total_two_in_one
    label[j] = label_two_in_one
#    total[j] = str(total[j]).replace("['","").replace("']","")
#    label[j] = str(label[j]).replace("['","").replace("']","")


print("label: ",label)
print("total: ",total)
#total_csv = [x / 10 for x in range(len(total))]
#print("total_csv:",total_csv)

#for j in range(len(csv)):
#    for i in range(2):
#        total[j][i].append(ground_truth[j][i])
#print(total)
total = pd.DataFrame([total, label]).T
print(total)
total.columns = ["ans","label"]
total.to_csv('CNN_output_predict10.csv',index = False)
