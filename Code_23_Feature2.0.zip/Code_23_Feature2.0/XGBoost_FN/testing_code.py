import numpy as np
import pandas as pd
import sys, os, pickle
import xgboost as xgb
import tensorflow.keras as keras
path='format_combine/test/'
std_mean_value = np.array(pd.read_csv('format_combine/std_mean/std_mean_value.csv', na_filter = False, header = None))
feature_num = 23
slot_num = 10
RP_num = [0,114,176,108,141,385,559]
def preprocessing(path=str, feature_num=int, Label_channel=0, valid_split_rate=0.01):
	csv_name_list=[x for x in os.listdir(path)]
	x_test = []
	y_label = []
	reg = []
	reg1 = []
	for i in sorted(csv_name_list):
		x_test.append(np.array(pd.read_csv(path+i, na_filter = False, header = None))) # read_csv : 讀取檔案 ; na_filter : 是否檢查丟失值
		y_label.append(''.join([k for k in i if k.isdigit()]))
	for i in range(len(x_test)):
		print(len(x_test[i]))
		for j in range(len(x_test[i])):
			tmp = str(x_test[i][j])
			#feature_num = len(tmp)
			reg.append(tmp.replace("['","").replace("']","").replace("\\t",",").split(','))
			if y_label[i] == '1':
				reg1.append('-274,280'.split(','))
			elif y_label[i] == '2':
				reg1.append('0,280'.split(','))
			elif y_label[i] == '3':
				reg1.append('263.5,280'.split(','))
			elif y_label[i] == '4':
				reg1.append('-274,0'.split(','))
			elif y_label[i] == '5':
				reg1.append('263.5,0'.split(','))
			elif y_label[i] == '6':
				reg1.append('-274,-317'.split(','))
			elif y_label[i] == '7':
				reg1.append('0,-317'.split(','))
			else:
				reg1.append('263.5,-317'.split(','))
	N = len(reg)
	#print('N: ',N)
	x_n_test = np.array(reg).reshape(N,feature_num) # N,23
	y_n_label = np.array(reg1).reshape(N,2) # N,2

	x_n_test = x_n_test.astype('float64') 
	y_n_label = y_n_label.astype('float64')

	# Standardization
	tmp = np.zeros([N, feature_num])

	for j in range(feature_num):
		print("std_check: ",std_mean_value[0,j])
		print("mean_check: ",std_mean_value[1,j])
		std_t = std_mean_value[0,j]
		mean_t = std_mean_value[1,j]
		for i in range(N): 
			tmp[i][j] = (x_n_test[i][j] - mean_t) / (std_t + 1e-5)

	x_n_test = tmp
	print('x_n_test[0]',x_n_test[0],';size:',len(x_n_test[0]))
	test_data, test_label = x_n_test[:].T[:].T,y_n_label[:].T[Label_channel].T
	print(len(test_data))
	# print(test_label)
	return test_data, test_label

def FN_mainTest(xgb_predict_value=list, ground_truth=list):
	XGB_output = np.array([xgb_predict_value])
	ground_truth = np.array([ground_truth])
	out_pred_format = []
	out_label_format = []
	str1 = ','
	for i in range((XGB_output).reshape(-1,1).shape[0]):
		out_pred_format.append(str1.join( (XGB_output.reshape(-1,1)[i]).astype('str') ))
		out_label_format.append(str1.join( (ground_truth.reshape(-1,1)[i]).astype('str') ))
	model1 = keras.models.load_model('FN.h5')
	index = 0
	ans = np.array([])
	label = np.array([])
	for i in range(1,7):
		index = index + RP_num[i]
		remove_num = RP_num[i] % slot_num
		print(index-RP_num[i],index-remove_num)
		tmp1 = np.array([out_pred_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)
		print(tmp1)
		XGB_output_by_slot = np.array([])
		for j in range(tmp1.shape[0]):
			for k in range(10):
				print(tmp1[j][k])
				if XGB_output_by_slot.shape[0] == 0:
					XGB_output_by_slot = np.array([str(tmp1[j][k]).split(',')])
				else:
					XGB_output_by_slot = np.append(XGB_output_by_slot, [str(tmp1[j][k]).split(',')])
		XGB_output_by_slot = XGB_output_by_slot.astype('float64')
		print(len(XGB_output_by_slot.reshape(-1,slot_num*2)))
		predict_value1 = model1.predict(XGB_output_by_slot.reshape(-1,slot_num*2))
		if ans.shape[0] == 0:
			ans = np.array([predict_value1])
		else:
			ans = np.append(ans, predict_value1)

		label_tmp = np.array([out_label_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)[:,0]
		if label.shape[0] == 0:
			label = np.array([label_tmp])
		else:
			label = np.append(label, label_tmp)
	out_pred_format = []
	str1 = ','
	for i in range((ans).reshape(-1,2).shape[0]):
		out_pred_format.append(str1.join( (ans.reshape(-1,2)[i]).astype('str') ))
	out = pd.DataFrame([out_pred_format,label]).T
	out.columns = ["ans","label"]
	out.to_csv('XGBoost_and_FN_output_predict.csv',index = False) 

def main():
	test_data, test_label_x = preprocessing(path, feature_num)
	model_1 = pickle.load(open("x.pickle", "rb"))
	print(model_1)
	test_x = model_1.predict(test_data)

	test_data, test_label_y = preprocessing(path, feature_num, Label_channel=1)
	model_2 = pickle.load(open("y.pickle", "rb"))
	print(model_2)
	test_y = model_2.predict(test_data)
	print(test_x, test_y)
	predict_value = []
	ground_truth = []
	str1 = ','
	for i in range(test_x.shape[0]):

		predict_value.append(str1.join( np.append(test_x[i].astype('float64') ,test_y[i].astype('float64') ).astype('str') ))
		ground_truth.append(str1.join( np.append(test_label_x[i].astype('float64') ,test_label_y[i].astype('float64') ).astype('str') ))

	out = pd.DataFrame([predict_value,ground_truth]).T
	out.columns = ["ans","label"]
	out.to_csv('xboost_output_predict.csv',index = False)

	FN_mainTest(predict_value, ground_truth)

if __name__ == "__main__":
	main()
