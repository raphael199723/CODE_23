import numpy as np
import pandas as pd
import sys
from tensorflow import keras
from tensorflow.keras import layers
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout,BatchNormalization,Conv1D
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import RMSprop,Adam
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler ,MinMaxScaler
import os
path='format_combine/test/'
std_mean_value = np.array(pd.read_csv('format_combine/std_mean/std_mean_value.csv', na_filter = False, header = None))
feature_num = 23
slot_num = 10
def preprocessing(path=str, feature_num=int):
	csv_name_list=[x for x in os.listdir(path)]
	x_test = []
	y_label = []
	reg = []
	reg1 = []
	reg2 = []
	RP_num = [0,102,111,129,179,170,151]
	for i in sorted(csv_name_list):
		x_test.append(np.array(pd.read_csv(path+i, na_filter = False, header = None))) # read_csv : read csv file; na_filter : whether detect missing value markers or not
		y_label.append(''.join([k for k in i if k.isdigit()]))
	for i in range(len(x_test)):
		#print(len(x_test[i]))
		for j in range(len(x_test[i])):
			tmp = str(x_test[i][j])
			#feature_num = len(tmp)
			reg.append(tmp.replace("['","").replace("']","").replace("\\t",",").split(','))
			if y_label[i] == '1':
				reg1.append('-274,280'.split(','))
			elif y_label[i] == '2':
				reg1.append('263.5,280'.split(','))
			elif y_label[i] == '3':
				reg1.append('-274,0'.split(','))
			elif y_label[i] == '4':
				reg1.append('263.5,0'.split(','))
			elif y_label[i] == '5':
				reg1.append('-274,-317'.split(','))
			else:
				reg1.append('263.5,-317'.split(','))
	N = len(reg)
	print('y_label: ',y_label[i])
	x_n_test = np.array(reg)#.reshape(N,feature_num) # N,23
	y_n_label = np.array(reg1).reshape(N,2) # N,2
	# print((x_n_test.dtype))
	# print((y_n_label.dtype))
	x_n_test = x_n_test.astype('float64') 
	y_n_label = y_n_label.astype('float64')

	# Standardization
	tmp = np.zeros([N, feature_num])

	for j in range(feature_num):
		print("std_check: ",std_mean_value[0,j])
		print("mean_check: ",std_mean_value[1,j])
		std_t = std_mean_value[0,j]
		mean_t = std_mean_value[1,j]
		for i in range(N): 
			tmp[i][j] = (x_n_test[i][j] - mean_t) / std_t

	x_n_test = tmp
	print('x_n_test[0]',x_n_test[0],';size:',len(x_n_test[0]))
	x_n_test = x_n_test.reshape(int(len(x_n_test)),23,1) #B,W,H,Channel ; B*W=total num
	return x_n_test, y_n_label, RP_num

def main():
	x_n_test, y_n_label, RP_num = preprocessing(path, feature_num)

	model = keras.models.load_model('CNN1d.h5')
	predict_value = model.predict(x_n_test)
	#print(predict_value, np.sum(predict_value[1300]))
	ans = np.array([])
	RP1 = np.array([-274,280])
	RP2 = np.array([0,280])
	RP3 = np.array([263.5,280])
	RP4 = np.array([-274,0])
	RP5 = np.array([263.5,0])
	RP6 = np.array([-274,-317])
	RP7 = np.array([0,-317])
	RP8 = np.array([263.5,-317])
	print('len:',predict_value.shape[0])
	for i in range(predict_value.shape[0]):
		tmp=RP1*predict_value[i][0]+RP3*predict_value[i][1]+RP4*predict_value[i][2]+RP5*predict_value[i][3]+RP6*predict_value[i][4]+RP8*predict_value[i][5]
		if ans.shape[0] == 0:
			ans = np.array([tmp])
		else:
			ans = np.append(ans, tmp)
	print((ans).reshape(-1,2)[0:20])
	print(y_n_label.reshape(-1,2)[0:20])
	print((ans).reshape(-1,2)[822:842])
	print(y_n_label.reshape(-1,2)[822:842])
	out_pred_format = []
	out_label_format = []
	str1 = ','
	for i in range((ans).reshape(-1,2).shape[0]):
		out_pred_format.append(str1.join( (ans.reshape(-1,2)[i]).astype('str') ))
		out_label_format.append(str1.join( (y_n_label.reshape(-1,2)[i]).astype('str') ))
	out = pd.DataFrame([out_pred_format,out_label_format]).T
	out.columns = ["ans","label"]
	out.to_csv('CNN1d_output_predict.csv',index = False)

	model1 = keras.models.load_model('FN.h5')
	index = 0
	ans = np.array([])
	label = np.array([])
	for i in range(1,7):
		index = index + RP_num[i]
		remove_num = RP_num[i] % slot_num
		print("check two: ",index-RP_num[i],index-remove_num)
		#print("len: ",len(np.array([out_pred_format[index-RP_num[i]:index-Remove_num]]).reshape(-1,1)))
		#tmp1 = np.array([out_pred_format[0:40]]).reshape(-1,slot_num)
		#print("check out__pred_format:", len(out_pred_format))
		tmp1 = np.array([out_pred_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)
		print("tmp1",len(tmp1))
		DNN_output_by_slot = np.array([])
		for j in range(tmp1.shape[0]):
			for k in range(10):
				#print(tmp1[j][k])
				if DNN_output_by_slot.shape[0] == 0:
					DNN_output_by_slot = np.array([str(tmp1[j][k]).split(',')])
				else:
					DNN_output_by_slot = np.append(DNN_output_by_slot, [str(tmp1[j][k]).split(',')])
		DNN_output_by_slot = DNN_output_by_slot.astype('float64')
		#print(len(DNN_output_by_slot.reshape(-1,slot_num*2)))
		predict_value1 = model1.predict(DNN_output_by_slot.reshape(-1,slot_num*2))
		if ans.shape[0] == 0:
			ans = np.array([predict_value1])
		else:
			ans = np.append(ans, predict_value1)

		label_tmp = np.array([out_label_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)[:,0]
		if label.shape[0] == 0:
			label = np.array([label_tmp])
		else:
			label = np.append(label, label_tmp)
	out_pred_format = []
	str1 = ','
	for i in range((ans).reshape(-1,2).shape[0]):
		out_pred_format.append(str1.join( (ans.reshape(-1,2)[i]).astype('str') ))
	out = pd.DataFrame([out_pred_format,label]).T
	out.columns = ["ans","label"]
	out.to_csv('CNN1D_and_FN_output_predict.csv',index = False)
if __name__ == "__main__":
	main()
